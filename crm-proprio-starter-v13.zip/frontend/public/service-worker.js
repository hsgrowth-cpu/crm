
const VERSION = 'hs-crm-v12';
const STATIC_CACHE = `static-${VERSION}`;
const RUNTIME_CACHE = `runtime-${VERSION}`;
const CORE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/offline.html'
];

// ---- Workbox (CDN) ----
try {
  importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.5.4/workbox-sw.js');
  if (self.workbox) {
    const { routing, strategies, expiration, cacheableResponse, precaching } = workbox;
    // Precaching: apenas core já está em CACHE; não usamos manifest do build Vite aqui.
    // Rotas estáticas: imagens/fonts -> CacheFirst + Expiration
    routing.registerRoute(
      ({request}) => ['image','font'].includes(request.destination),
      new strategies.CacheFirst({
        cacheName: 'static-media',
        plugins: [new expiration.ExpirationPlugin({ maxEntries: 200, maxAgeSeconds: 30*24*3600 })]
      })
    );
    // API GET -> StaleWhileRevalidate
    routing.registerRoute(
      ({url, request}) => request.method === 'GET' && url.pathname.startsWith('/api/'),
      new strategies.StaleWhileRevalidate({
        cacheName: 'api-swr',
        plugins: [new expiration.ExpirationPlugin({ maxEntries: 200, maxAgeSeconds: 3600 })]
      })
    );
    // JS/CSS -> StaleWhileRevalidate
    routing.registerRoute(
      ({request}) => request.destination === 'script' || request.destination === 'style',
      new strategies.StaleWhileRevalidate({
        cacheName: 'assets-swr',
        plugins: [new expiration.ExpirationPlugin({ maxEntries: 150, maxAgeSeconds: 7*24*3600 })]
      })
    );
  }
} catch(e){ /* fallback para nossa lógica manual abaixo */ }


// --- Minimal IndexedDB wrapper ---
const idb = {
  db: null,
  async open(){
    return new Promise((resolve,reject)=>{
      const req = indexedDB.open('hs-crm-idb', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if(!db.objectStoreNames.contains('queue_tasks')) db.createObjectStore('queue_tasks', { keyPath: 'id', autoIncrement: true });
        db.createObjectStore('queue_wa', { keyPath: 'id', autoIncrement: true });
      };
      req.onsuccess = ()=>{ idb.db = req.result; resolve(idb.db); };
      req.onerror = ()=> reject(req.error);
    });
  },
  async add(item){
    const db = idb.db || await idb.open();
    return new Promise((resolve,reject)=>{
      const tx = db.transaction('queue_tasks','readwrite');
      tx.objectStore('queue_tasks').add(item);
      tx.oncomplete = ()=> resolve(true);
      tx.onerror = ()=> reject(tx.error);
    });
  },
  async all(){
    const db = idb.db || await idb.open();
    return new Promise((resolve,reject)=>{
      const tx = db.transaction('queue_tasks','readonly');
      const req = tx.objectStore('queue_tasks').getAll();
      req.onsuccess = ()=> resolve(req.result || []);
      req.onerror = ()=> reject(req.error);
    });
  },
  async del(id){
    const db = idb.db || await idb.open();
    return new Promise((resolve,reject)=>{
      const tx = db.transaction('queue_tasks','readwrite');
      tx.objectStore('queue_tasks').delete(id);
      tx.oncomplete = ()=> resolve(true);
      tx.onerror = ()=> reject(tx.error);
    });
  }
};


const LOGS = [];
function log(msg){ try{ LOGS.push({ t: Date.now(), msg }); if (LOGS.length>200) LOGS.shift(); }catch(e){} }

function withTTL(cacheName, maxEntries=200, maxAgeSeconds=86400){
  return {
    async put(req, res){
      const cache = await caches.open(cacheName);
      await cache.put(new Request(req, { headers: { 'x-sw-cache-time': String(Date.now()) } }), res);
      await enforceCacheLimit(cacheName, maxEntries);
    },
    async match(req){
      const cache = await caches.open(cacheName);
      const cached = await cache.match(req);
      if (!cached) return null;
      // TTL check
      const timeHeader = cached.headers.get('x-sw-cache-time');
      const now = Date.now();
      if (timeHeader && (now - Number(timeHeader)) > maxAgeSeconds*1000){
        cache.delete(req);
        return null;
      }
      return cached;
    }
  }
}

self.addEventListener('install', e => {
  e.waitUntil((async()=>{
    const c = await caches.open(STATIC_CACHE);
    await c.addAll(CORE);
    self.skipWaiting();
  })());
});


async function enforceCacheLimit(cacheName, maxEntries){
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length > maxEntries){
    const toDelete = keys.length - maxEntries;
    for (let i=0; i<toDelete; i++){ await cache.delete(keys[i]); }
  }
}
self.addEventListener('activate', e => {
  e.waitUntil((async()=>{
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => ![STATIC_CACHE,RUNTIME_CACHE].includes(k)).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

// Notify clients about updates (optional prompt)
async function broadcastUpdate(){
  const clients = await self.clients.matchAll({ type:'window', includeUncontrolled:true });
  for (const c of clients){
    c.postMessage({ type:'SW_UPDATED', version: VERSION });
  }
}

// Background sync registration helper
async function registerSync(){
  if ('sync' in self.registration) {
    try { await self.registration.sync.register('hs-crm-sync'); } catch(e){}
  }
}

// Runtime caching
self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);

  // Only handle same-origin
  if (url.origin !== location.origin) return;

  // HTML navigation fallback to offline
  if (req.mode === 'navigate') {
    event.respondWith((async()=>{
      try {
        const resp = await fetch(req);
        return resp;
      } catch {
        const cache = await caches.open(STATIC_CACHE);
        const cached = await cache.match('/offline.html');
        return cached;
      }
    })());
    return;
  }

  // API GET: stale-while-revalidate
  if (req.method === 'GET' && url.pathname.startsWith('/api/')) {
    event.respondWith((async()=>{
      const rt = withTTL(RUNTIME_CACHE, 200, 3600);
      const cached = await rt.match(req);
      const network = fetch(req).then(res => {
        rt.put(req, res.clone());
        return res;
      }).catch(()=>null);
      return cached || network || new Response(JSON.stringify({ error:'offline' }), { status: 503, headers: { 'Content-Type':'application/json' } });
    })());
    return;
  }

  // API POST to tasks or whatsapp: queue when offline
  if (req.method === 'POST' && url.pathname.startsWith('/api/tasks')) {
    event.respondWith((async()=>{
      try {
        const res = await fetch(req.clone());
        return res;
      } catch (e) {
        // queue to idb
        const body = await req.clone().text();
        await idb.add({ url: url.pathname, method: 'POST', body, headers: [...req.headers.entries()] });
        try{ await self.registration.sync.register('hs-crm-sync-tasks'); }catch(e){}
        log('queue: tasks'); return new Response(JSON.stringify({ queued:true, message:'Ação pendente. Vamos sincronizar quando voltar a conexão.' }), { status: 202, headers:{'Content-Type':'application/json'} });
      }
    })());
    return;
  }

  // Static: cache-first
  event.respondWith((async()=>{
    const st = withTTL(STATIC_CACHE, 150, 7*24*3600);
    const cached = await st.match(req);
    if (cached) return cached;
    try {
      const res = await fetch(req);
      rt.put(req, res.clone());
      return res;
    } catch {
      return cached || new Response('offline', { status: 503 });
    }
  })());
});

// Sync handler: replay queued requests
self.addEventListener('sync', e => {
  if (e.tag === 'hs-crm-sync-tasks') {
    e.waitUntil((async()=>{
      const items = await idb.all();
      for (const item of items){
        try {
          const headers = new Headers(item.headers || []);
          const res = await fetch(item.url, { method: item.method || 'POST', headers, body: item.body || '' });
          if (res.ok) await idb.del(item.id);
        } catch {}
      }
      await broadcastUpdate();
    })());
  }
});

// Message from page (e.g., request pending count)
self.addEventListener('message', async (e) => {
  
  if (e.data && e.data.type === 'CACHE_METRICS') {
    const names = await caches.keys();
    const counts = {};
    for (const n of names){
      const c = await caches.open(n);
      const keys = await c.keys();
      counts[n] = { entries: keys.length };
    }
    e.source?.postMessage({ type:'CACHE_METRICS_ACK', counts });
    return;
  }
  if (e.data && e.data.type === 'GET_LOGS') {
    e.source?.postMessage({ type:'LOGS', logs: LOGS.slice(-100) });
    return;
  }
  if (e.data && e.data.type === 'REPLAY_NOW') {
    // trigger both syncs immediately
    const replay = async(store, tag) => {
      try {
        if (tag==='tasks') {
          const items = await idb.all();
          for (const item of items){
            try { const headers = new Headers(item.headers||[]); const r = await fetch(item.url, { method:item.method||'POST', headers, body:item.body||'' }); if (r.ok) await idb.del(item.id); } catch(err){ log('replay tasks err'); }
          }
        } else {
          const items = await idbWA.all();
          for (const item of items){
            try { const headers = new Headers(item.headers||[]); const r = await fetch(item.url, { method:item.method||'POST', headers, body:item.body||'' }); if (r.ok) await idbWA.del(item.id); } catch(err){ log('replay wa err'); }
          }
        }
      } catch(e){}
    };
    await replay('tasks','tasks'); await replay('wa','wa');
    const clients = await self.clients.matchAll({ type:'window' });
    clients.forEach(c=>c.postMessage({ type:'REPLAY_DONE' }));
    return;
  }

  if (e.data && e.data.type === 'PENDING_COUNT') {
    const items = await idb.all();
    const count = items.length;
    e.source?.postMessage({ type:'PENDING_COUNT_ACK', count });
  }
});

// Second store for WhatsApp
const idbWA = {
  db: null,
  async open(){ if (idb.db) { this.db = idb.db; return this.db; } return idb.open(); },
  async add(item){ const db = this.db || await this.open(); return new Promise((res,rej)=>{ const tx=db.transaction('queue_wa','readwrite'); tx.objectStore('queue_wa').add(item); tx.oncomplete=()=>res(true); tx.onerror=()=>rej(tx.error); }); },
  async all(){ const db = this.db || await this.open(); return new Promise((res,rej)=>{ const tx=db.transaction('queue_wa','readonly'); const r=tx.objectStore('queue_wa').getAll(); r.onsuccess=()=>res(r.result||[]); r.onerror=()=>rej(r.error); }); },
  async del(id){ const db = this.db || await this.open(); return new Promise((res,rej)=>{ const tx=db.transaction('queue_wa','readwrite'); tx.objectStore('queue_wa').delete(id); tx.oncomplete=()=>res(true); tx.onerror=()=>rej(tx.error); }); },
};

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (req.method === 'POST' && url.pathname.startsWith('/api/whatsapp')) {
    event.respondWith((async()=>{
      try { const res = await fetch(req.clone()); return res; }
      catch(e){
        const body = await req.clone().text();
        await idbWA.add({ url: url.pathname, method:'POST', body, headers:[...req.headers.entries()] });
        try{ await self.registration.sync.register('hs-crm-sync-wa'); }catch(e){}
        log('queue: whatsapp'); return new Response(JSON.stringify({ queued:true, message:'WhatsApp pendente. Enviaremos quando a conexão voltar.' }), { status:202, headers:{'Content-Type':'application/json'} });
      }
    })());
  }
});

self.addEventListener('sync', e => {
  if (e.tag === 'hs-crm-sync-wa') {
    e.waitUntil((async()=>{
      const items = await idbWA.all();
      for (const item of items){
        try {
          const headers = new Headers(item.headers || []);
          const res = await fetch(item.url, { method: item.method || 'POST', headers, body: item.body || '' });
          if (res.ok) await idbWA.del(item.id);
        } catch {}
      }
      const cs = await self.clients.matchAll({ type:'window' }); cs.forEach(c=>c.postMessage({ type:'SW_UPDATED', version: VERSION }));
    })());
  }
});

self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch(e){}
  const title = data.title || 'HS Growth CRM';
  const options = {
    body: data.body || 'Você tem uma atualização.',
    actions: [
      { action:'open', title:'Abrir' },
      { action:'done', title:'Concluir tarefa' }
    ],
    icon: '/icon-192.png',
    badge: '/icon-64.png',
    data: { url: data.url || '/' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  if (event.action === 'done' && event.notification.data?.taskId) {
    // try to mark task as done
    event.waitUntil(fetch('/api/tasks/'+event.notification.data.taskId, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ done:1, title:'', due_at:'', client_id:null, assigned_to:null, channel:'whatsapp', notes:'' }) }).catch(()=>{}));
    event.notification.close();
    return;
  }
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(clients.openWindow(url));
});
