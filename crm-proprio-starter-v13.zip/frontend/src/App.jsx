import React, { useState, useEffect } from 'react'
import { api, setToken, getToken } from './api'

function Login({ onLogin }){
  const [email, setEmail] = useState('admin@hsgrowth.com')
  const [password, setPassword] = useState('admin123')
  const [err, setErr] = useState('')
  async function submit(e){
    e.preventDefault()
    try{
      const data = await api('/api/auth/login', { method:'POST', body: JSON.stringify({ email, password }) })
      setToken(data.token)
      onLogin(data.user)
    }catch(e){ setErr('Falha no login') }
  }
  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="card" style={{maxWidth:420, margin:'80px auto'}}>
        <h2>Entrar no HS Growth CRM</h2>
        <form onSubmit={submit}>
          <div><input placeholder="E-mail" value={email} onChange={e=>setEmail(e.target.value)} /></div>
          <div style={{marginTop:8}}><input type="password" placeholder="Senha" value={password} onChange={e=>setPassword(e.target.value)} /></div>
          {err && <p style={{color:'#ff9f9f'}}>{err}</p>}
          <div style={{marginTop:12}}><button type="submit">Entrar</button></div>
        </form>
        <p style={{opacity:.7, marginTop:8}}>Usuário seed: admin@hsgrowth.com / admin123</p>
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function Sidebar({ page, setPage }){
  const link = (id, label)=> <a href="#" className={page===id?'active':''} onClick={()=>setPage(id)}>{label}</a>
  return (
    <div className="sidebar">
      <div className="logo">HS Growth CRM</div>
      <div className="nav">
        {link('dashboard','Dashboard')}
        {link('clients','Clientes')}
        {link('deals','Negócios')}
        {link('kanban','Kanban')}
        {link('reports','Relatórios')}
        {link('tasks','Tarefas / Agenda')}
            {link('adminpwa','Admin PWA')}
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function Header({ user, setPage, onStartTour }){
  function toggleTheme(){
    const isLight = document.body.dataset.theme === 'light'
    document.body.dataset.theme = isLight ? 'dark' : 'light'
    localStorage.setItem('crm_theme', document.body.dataset.theme)
    // apply CSS vars
    const r = getComputedStyle(document.documentElement)
    const map = (k) => getComputedStyle(document.documentElement).getPropertyValue(k).trim()
    const vars = document.body.dataset.theme === 'light'
      ? { bg: map('--bg-light'), panel: map('--panel-light'), text: map('--text-light'), line: map('--line-light') }
      : { bg: map('--bg'), panel: map('--panel'), text: map('--text'), line: map('--line') }
    document.body.style.background = vars.bg
    document.querySelectorAll('.card').forEach(el=>{ el.style.background = vars.panel; el.style.borderColor = vars.line })
  }

  return (
    <header>
      <img src="/icon-192.png" alt="logo" style={{height:24, verticalAlign:'middle', marginRight:10}}/> HS Growth CRM — <a href="#" onClick={()=>setPage('dashboard')}>Dashboard</a> · <a href="#" onClick={()=>setPage('clients')}>Clientes</a> · <a href="#" onClick={()=>setPage('deals')}>Negócios</a>
      <span style={{float:'right'}}>
        <span id="pendingDot" className="pill" style={{marginRight:10, display:'none'}}>Pendências</span>
        <button onClick={toggleTheme} style={{marginRight:10}}>Tema</button> Olá, {user?.name} <button onClick={onStartTour} style={{marginLeft:10}}>Tour ?</button></span>
    </header>
  )
}

function Dashboard(){
  const [clients, setClients] = useState([])
  const [deals, setDeals] = useState([])
  useEffect(()=>{
    api('/api/clients').then(setClients).catch(()=>{})
    api('/api/deals').then(setDeals).catch(()=>{})
  },[])
  const ganho = deals.filter(d=>d.stage==='won').reduce((a,b)=>a+b.value,0)
  const total = deals.reduce((a,b)=>a+b.value,0)
  const conv = deals.length ? (deals.filter(d=>d.stage==='won').length / deals.length) * 100 : 0
  const byStage = deals.reduce((acc,d)=>{acc[d.stage]=(acc[d.stage]||0)+d.value;return acc;}, {})
  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="row">
        <div className="card" style={{flex:'1 1 240px'}}>
          <h3>Leads/Clientes</h3>
          <p>Total: <b>{clients.length}</b></p>
        </div>
        <div className="card" style={{flex:'1 1 240px'}}>
          <h3>Negócios</h3><div className="toolbar"><button onClick={async()=>{ const rows = await api('/api/deals'); download('negocios.csv', toCSV(rows)); }}>Exportar CSV</button> <label className="pill" htmlFor="import_deals" style={{cursor:'pointer'}}>Importar CSV</label><input type="file" id="import_deals" style={{display:'none'}} onChange={async e=>{ if(e.target.files[0]) await importCSV(e.target.files[0], 'deals'); await load(); }} /> <input placeholder="Filtrar por owner_user_id" onChange={async e=>{const v=e.target.value; const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setList(await api(url));}} /></div>
          <p>Total: <b>{deals.length}</b></p>
        </div>
        <div className="card" style={{flex:'1 1 240px'}}>
          <h3>Receita Ganhos</h3>
          <p>R$ <b>{ganho.toFixed(2)}</b></p>
        </div>
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function toCSV(rows){
  if(!rows || !rows.length) return ''
  const headers = Object.keys(rows[0])
  const esc = v => ('"'+String(v).replace(/"/g,'""')+'"')
  const data = [headers.join(','), ...rows.map(r => headers.map(h=>esc(r[h]??'')).join(','))]
  return data.join('\n')
}
function download(filename, text){
  const blob = new Blob([text], {type:'text/csv;charset=utf-8;'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href=url; a.download=filename; a.click()
  URL.revokeObjectURL(url)
}

function Clients(){

      async function importCSV(file, type){
        const text = await file.text()
        const rows = text.split(/\r?\n/).filter(Boolean).map(l=>l.split(/,(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/).map(s=>s.replace(/^"|"$/g,'')))
        const headers = rows.shift().map(h=>h.trim())
        const idx = name => headers.indexOf(name)
        const post = async (url, obj) => { try { await api(url, { method:'POST', body: JSON.stringify(obj) }) } catch(e){} }
        if(type==='clients'){
          for(const r of rows){
            const obj = {
              name: r[idx('name')]||'',
              email: r[idx('email')]||'',
              phone: r[idx('phone')]||'',
              company: r[idx('company')]||'',
              status: r[idx('status')]||'lead',
              source: r[idx('source')]||'',
              owner: r[idx('owner')]||'',
              tags: r[idx('tags')]||'',
              owner_user_id: r[idx('owner_user_id')]? Number(r[idx('owner_user_id')]) : null
            }
            await post('/api/clients', obj)
          }
        } else {
          for(const r of rows){
            const obj = {
              client_id: Number(r[idx('client_id')]),
              value: Number(r[idx('value')]||0),
              stage: r[idx('stage')]||'new',
              expected_close: r[idx('expected_close')]||null,
              owner_user_id: r[idx('owner_user_id')]? Number(r[idx('owner_user_id')]) : null
            }
            await post('/api/deals', obj)
          }
        }
        alert('Importação concluída')
      }

  const [list, setList] = useState([])
  const [form, setForm] = useState({ name:'', email:'', phone:'', company:'', status:'lead', source:'', owner:'', tags:'' })
  async function load(){ setList(await api('/api/clients')) }
  useEffect(()=>{ load() },[])
  async function add(e){
    e.preventDefault()
    await api('/api/clients', { method:'POST', body: JSON.stringify(form) })
    setForm({ name:'', email:'', phone:'', company:'', status:'lead' })
    await load()
  }
  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="card">
        <h3>Novo cliente</h3>
        <form onSubmit={add} className="row">
          <input placeholder="Nome" value={form.name} onChange={e=>setForm({...form, name:e.target.value})}/>
          <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
          <input placeholder="Telefone" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})}/>
          <input placeholder="Empresa" value={form.company} onChange={e=>setForm({...form, company:e.target.value})}/>
          <input placeholder="Origem (source)" value={form.source} onChange={e=>setForm({...form, source:e.target.value})}/>
          <input placeholder="Responsável (owner)" value={form.owner} onChange={e=>setForm({...form, owner:e.target.value})}/>
          <input placeholder="Tags (vírgulas)" value={form.tags} onChange={e=>setForm({...form, tags:e.target.value})}/>
          <select value={form.status} onChange={e=>setForm({...form, status:e.target.value})}>
            <option value="lead">Lead</option>
            <option value="proposal">Proposta</option>
            <option value="won">Fechado (Ganho)</option>
            <option value="lost">Perdido</option>
          </select>
          <button>Salvar</button>
        </form>
      </div>
      <div className="card">
        <h3>Clientes</h3>
        <div className="toolbar">Clientes — filtros: <input id="flt_owner" placeholder="Responsável contém" onInput={(e)=>{const v=e.target.value.toLowerCase(); document.querySelectorAll('tbody tr').forEach(tr=>{const owner=(tr.getAttribute('data-owner')||'').toLowerCase(); tr.style.display = owner.includes(v) ? '' : 'none';});}} /> <select id="flt_status" onChange={(e)=>{const v=e.target.value; document.querySelectorAll('tbody tr').forEach(tr=>{const st=(tr.getAttribute('data-status')||''); tr.style.display = (!v || st===v)? '' : 'none';});}}><option value="">Status</option><option value="lead">Lead</option><option value="proposal">Proposta</option><option value="won">Fechado (Ganho)</option><option value="lost">Perdido</option></select> <input id="flt_tag" placeholder="Tag contém" onInput={(e)=>{const v=e.target.value.toLowerCase(); document.querySelectorAll('tbody tr').forEach(tr=>{const tags=(tr.getAttribute('data-tags')||'').toLowerCase(); tr.style.display = tags.includes(v) ? '' : 'none';});}} /> <input id="flt_search" placeholder="Buscar nome/email/empresa" onInput={(e)=>{const v=e.target.value.toLowerCase(); document.querySelectorAll('tbody tr').forEach(tr=>{const text=(tr.innerText||'').toLowerCase(); tr.style.display = text.includes(v) ? '' : 'none';});}} /></div><div className="toolbar"><button onClick={async()=>{ const rows = await api('/api/clients'); download('clientes.csv', toCSV(rows)); }}>Exportar CSV</button></div>
        <table>
          <thead><tr><th>Nome</th><th>Email</th><th>Fone</th><th>Empresa</th><th>Status</th><th>Origem</th><th>Responsável</th><th>Tags</th></tr></thead>
          <tbody>
            {list.map(c => <tr key={c.id} data-owner={c.owner||''} data-status={c.status||''} data-tags={c.tags||''}><td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td><td>{c.company}</td><td>{c.status}</td><td>{c.source||'-'}</td><td>{c.owner||'-'}</td><td>{c.tags||'-'}</td></tr>)}
          </tbody>
        </table>
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}

function Deals(){
  const [clients, setClients] = useState([])
  const [users, setUsers] = useState([])
  const [list, setList] = useState([])
  const [form, setForm] = useState({ client_id:'', value:'', stage:'new', expected_close:'', owner_user_id:'' })
  async function load(){
    setClients(await api('/api/clients'))
    setUsers(await api('/api/users'))
    setList(await api('/api/deals'))
  }
  useEffect(()=>{ load() },[])
  async function add(e){
    e.preventDefault()
    await api('/api/deals', { method:'POST', body: JSON.stringify({ ...form, value: Number(form.value), owner_user_id: form.owner_user_id?Number(form.owner_user_id):null }) })
    setForm({ client_id:'', value:'', stage:'new', expected_close:'' })
    await load()
  }
  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="card">
        <h3>Novo negócio</h3>
        <form onSubmit={add} className="row">
          <select value={form.client_id} onChange={e=>setForm({...form, client_id:e.target.value})}>
            <option value="">Selecione o cliente</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input placeholder="Valor (R$)" value={form.value} onChange={e=>setForm({...form, value:e.target.value})}/>
          <select value={form.stage} onChange={e=>setForm({...form, stage:e.target.value})}>
            <option value="new">Novo</option>
            <option value="proposal">Proposta</option>
            <option value="closing">Fechamento</option>
            <option value="won">Ganho</option>
            <option value="lost">Perdido</option>
          </select>
          <input type="date" value={form.expected_close} onChange={e=>setForm({...form, expected_close:e.target.value})}/>
          <select value={form.owner_user_id} onChange={e=>setForm({...form, owner_user_id:e.target.value})}>
            <option value="">Responsável (owner_user_id)</option>
            {users.map(u => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
          </select>
          <button>Salvar</button>
        </form>
      </div>
      <div className="card">
        <h3>Negócios</h3><div className="toolbar"><button onClick={async()=>{ const rows = await api('/api/deals'); download('negocios.csv', toCSV(rows)); }}>Exportar CSV</button> <label className="pill" htmlFor="import_deals" style={{cursor:'pointer'}}>Importar CSV</label><input type="file" id="import_deals" style={{display:'none'}} onChange={async e=>{ if(e.target.files[0]) await importCSV(e.target.files[0], 'deals'); await load(); }} /> <input placeholder="Filtrar por owner_user_id" onChange={async e=>{const v=e.target.value; const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setList(await api(url));}} /></div>
        <table>
          <thead><tr><th>Cliente</th><th>Valor</th><th>Etapa</th><th>Previsão</th></tr></thead>
          <tbody>
            {list.map(d => <tr key={d.id}><td>{d.client_name}</td><td>R$ {d.value.toFixed(2)}</td><td>{d.stage}</td><td>{d.expected_close || '-'}</td></tr>)}
          </tbody>
        </table>
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function Kanban(){
  const stages = ['new', 'proposal', 'closing', 'won', 'lost']
  const labels = { new:'Novo', proposal:'Proposta', closing:'Fechamento', won:'Ganho', lost:'Perdido' }
  const [deals, setDeals] = useState([])
  const [loading, setLoading] = useState(true)

  async function load(){
    setLoading(true)
    const d = await api('/api/deals')
    setDeals(d)
    setLoading(false)
  }
  useEffect(()=>{ load() }, [])
      useEffect(()=>{ (async()=>{ setUsers(await api('/api/users')) })() },[])

  function onDragStart(e, dealId){
    e.dataTransfer.setData('text/plain', String(dealId))
  }
  async function onDrop(e, stage){
    const id = Number(e.dataTransfer.getData('text/plain'))
    await api(`/api/deals/${id}`, { method:'PUT', body: JSON.stringify({ stage }) })
    await load()
  }
  function allowDrop(e){ e.preventDefault() }

  const totals = stages.reduce((acc,s)=>{ const arr = deals.filter(d=>d.stage===s); acc[s]={count:arr.length,total:arr.reduce((a,b)=>a+b.value,0)}; return acc; },{});
      const cols = stages.map(stage => ({
        stage,
        items: deals.filter(d => d.stage === stage)
      }))
      return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="row" style={{alignItems:'flex-start'}}>
        {cols.map(col => (
          <div key={col.stage} className="card" style={{flex:'1 1 220px', minHeight: 300}}
            onDrop={e=>onDrop(e, col.stage)} onDragOver={allowDrop}>
            <h3 style={{marginTop:0}}>{labels[col.stage]}</h3>
            {loading && <p>Carregando...</p>}
            {!loading && col.items.map(d => (
              <div key={d.id} className="card" draggable onDragStart={e=>onDragStart(e, d.id)} style={{background:'#0e0e0e'}}>
                <div style={{fontWeight:700}}>{d.client_name}</div>
                <div>R$ {d.value.toFixed(2)}</div>
                <div style={{opacity:.7, fontSize:12}}>Prev.: {d.expected_close || '-'}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function BarChart({ data }){
  const entries = Object.entries(data)
  const width = 600, height = 240, padding = 30
  const maxVal = Math.max(1, ...entries.map(([,v]) => v.total))
  const barW = (width - padding*2) / entries.length
  return (
    <svg width={width} height={height} style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
      {entries.map(([stage, info], i) => {
        const h = (info.total / maxVal) * (height - padding*2)
        const x = padding + i*barW
        const y = height - padding - h
        return (
          <g key={stage}>
            <rect x={x+6} y={y} width={barW-12} height={h} rx="6" />
            <text x={x + barW/2} y={height - 8} textAnchor="middle" fontSize="12" fill="#fff">{stage}</text>
            <text x={x + barW/2} y={y - 6} textAnchor="middle" fontSize="12" fill="#fff">R$ {info.total.toFixed(0)}</text>
          </g>
        )
      })}
    </svg>
  )
}


function Tasks(){
  const [tasks, setTasks] = useState([])
  const [clients, setClients] = useState([])
  const [form, setForm] = useState({ title:'', due_at:'', client_id:'', assigned_to:'', channel:'whatsapp', notes:'' })
  async function load(){ setTasks(await api('/api/tasks?only_open=1')); setClients(await api('/api/clients')); }
  useEffect(()=>{ load() },[])
  async function add(e){
    e.preventDefault()
    await api('/api/tasks', { method:'POST', body: JSON.stringify({ ...form, client_id: form.client_id||null, assigned_to: form.assigned_to?Number(form.assigned_to):null }) })
    setForm({ title:'', due_at:'', client_id:'', assigned_to:'', channel:'whatsapp', notes:'' })
    await load()
  }
  async function done(t){ await api(`/api/tasks/${t.id}`, { method:'PUT', body: JSON.stringify({ ...t, done: 1 }) }); await load() }
  async function run(){ await api('/api/tasks/run-reminders', { method:'POST' }); alert('Lembretes executados (veja resposta no backend).'); }
  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="card">
        <h3>Nova tarefa</h3>
        <form className="row" onSubmit={add}>
          <input placeholder="Título" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
          <input type="datetime-local" value={form.due_at} onChange={e=>setForm({...form, due_at:e.target.value})} />
          <select value={form.client_id} onChange={e=>setForm({...form, client_id:e.target.value})}>
            <option value="">Cliente (opcional)</option>
            {clients.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input placeholder="Assigned User ID (opcional)" value={form.assigned_to} onChange={e=>setForm({...form, assigned_to:e.target.value})} />
          <select value={form.channel} onChange={e=>setForm({...form, channel:e.target.value})}>
            <option value="whatsapp">WhatsApp</option>
            <option value="email">Email</option>
          </select>
          <input placeholder="Notas" value={form.notes} onChange={e=>setForm({...form, notes:e.target.value})} />
          <button>Salvar</button>
          <button type="button" onClick={run}>Rodar lembretes agora</button>
        </form>
      </div>
      <div className="card">
        <h3>Tarefas abertas</h3>
        <table>
          <thead><tr><th>Título</th><th>Cliente</th><th>Vence em</th><th>Canal</th><th>Ações</th></tr></thead>
          <tbody>
            {tasks.map(t => (
              <tr key={t.id}>
                <td>{t.title}</td>
                <td>{t.client_name || '-'}</td>
                <td>{t.due_at ? new Date(t.due_at).toLocaleString() : '-'}</td>
                <td><span className="pill">{t.channel}</span></td>
                <td><button onClick={()=>done(t)}>Concluir</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function AdminPWA(){
  const [info, setInfo] = useState({ version:'-', pending:0, publicKey:null, sub:null, msg:'', logs:[], caches:{} })
  async function refresh(){
    // ask SW for pending
    navigator.serviceWorker?.controller?.postMessage?.({ type:'PENDING_COUNT' })
  }
  useEffect(()=>{
    navigator.serviceWorker?.addEventListener?.('message', (e)=>{
      if(e.data?.type==='PENDING_COUNT_ACK'){
        setInfo(i=>({ ...i, pending: e.data.count||0 }))
      }
    })
    ;(async()=>{
      const r = await api('/api/push/public-key'); setInfo(i=>({ ...i, publicKey: r.publicKey }))
    })()
    refresh()
  },[])
  async function subscribe(){
    if (!('serviceWorker' in navigator)) return alert('SW não disponível');
    const reg = await navigator.serviceWorker.ready
    const key = info.publicKey
    if (!key) return alert('Sem VAPID_PUBLIC_KEY no backend')
    const sub = await reg.pushManager.subscribe({ userVisibleOnly:true, applicationServerKey: urlBase64ToUint8Array(key) })
    await api('/api/push/subscribe', { method:'POST', body: JSON.stringify(sub) })
    setInfo(i=>({ ...i, sub }))
    alert('Inscrito com sucesso')
  }
  async function test(){
    await api('/api/push/test-broadcast', { method:'POST', body: JSON.stringify({ message: info.msg || 'Ping do Admin' }) })
    alert('Broadcast solicitado (veja notificações)')
  }
  function checkUpdate(){ navigator.serviceWorker?.controller?.postMessage?.({ type:'CHECK_UPDATE' }); location.reload(); }
  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
  }
  return (
    <div className="container">
      <div className="card"><h3>Status do PWA</h3>
        <p>Versão do SW: <b>v11</b></p>
        <p>Pendências na fila: <b>{info.pending}</b></p>
        <div className="row">
          <button onClick={refresh}>Atualizar status</button>
          <button onClick={()=> navigator.serviceWorker?.controller?.postMessage?.({ type:'GET_LOGS' })}>Ver logs</button>
          <button onClick={()=> navigator.serviceWorker?.controller?.postMessage?.({ type:'CACHE_METRICS' })}>Ver métricas de cache</button>
          <button onClick={()=> navigator.serviceWorker?.controller?.postMessage?.({ type:'REPLAY_NOW' })}>Reprocessar agora</button>
          <button onClick={checkUpdate}>Checar atualização</button>
        
        <div className="card"><h3>Métricas de Cache</h3>
          <table><thead><tr><th>Cache</th><th>Entradas</th></tr></thead><tbody>
            {Object.entries(info.caches).map(([name,meta]) => <tr key={name}><td>{name}</td><td>{meta.entries}</td></tr>)}
          </tbody></table>
        </div>
    
        <div className="card"><h3>Logs do SW</h3>
          <div style={{maxHeight:240, overflow:'auto', fontFamily:'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize:12, background:'#0d0d0d', padding:12, borderRadius:8}}>
            {info.logs.map((l,i)=> <div key={i}>{new Date(l.t).toLocaleTimeString()} — {l.msg}</div>)}
          </div>
        </div>
      </div>
      <div className="card"><h3>Push Notifications</h3>
        <p>Public Key (VAPID): <code style={{fontSize:12}}>{info.publicKey || '—'}</code></p>
        <div className="row">
          <button onClick={subscribe}>Inscrever este dispositivo</button>
          <input placeholder="Mensagem de teste" value={info.msg} onChange={e=>setInfo({...info, msg:e.target.value})} />
          <button onClick={test}>Broadcast de teste</button>
        </div>
        <p style={{opacity:.7}}>Obs.: requer `VAPID_*` configurado no backend e permissão de notificações concedida.</p>
      </div>
    </div>
  )
}

function Reports(){
  const [deals, setDeals] = useState([])
  const [send, setSend] = useState({ to:'', message:'' })
  const [status, setStatus] = useState('')

  useEffect(()=>{ api('/api/deals').then(setDeals) },[])

  const byStage = deals.reduce((acc, d)=>{
    acc[d.stage] = acc[d.stage] || { count:0, total:0 }
    acc[d.stage].count += 1
    acc[d.stage].total += d.value
    return acc
  }, {})

      // Por responsável
      const byOwner = deals.reduce((acc,d)=>{ const k = d.owner_user_id || 'sem'; acc[k] = acc[k] || { count:0, total:0 }; acc[k].count++; acc[k].total += d.value; return acc; }, {})
      const totalDeals = deals.length || 1
      const won = (byStage['won']?.count)||0
      const conversion = (won/totalDeals)*100

  async function sendWhatsApp(e){
    e.preventDefault()
    setStatus('Enviando...')
    try{
      await api('/api/whatsapp/send', { method:'POST', body: JSON.stringify(send) })
      setStatus('✅ Mensagem enviada!')
      setSend({ to:'', message:'' })
    }catch(err){
      setStatus('❌ Falha ao enviar. Verifique configurações do servidor.')
    }
  }

  return (
    <div className="container"><div className="card"><div className="toolbar">Filtro: Responsável&nbsp;<select onChange={async e=>{ const v=e.target.value; setOwner(v); const url = v? `/api/deals?owner=${encodeURIComponent(v)}`:'/api/deals'; setDeals(await api(url)); }}><option value="">Todos</option>{users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}</select></div></div>
      <div className="row">
        {Object.entries(byStage).map(([stage, info]) => (
          <div key={stage} className="card" style={{flex:'1 1 220px'}}>
            <h3>{stage.toUpperCase()}</h3>
            <p>Qtde: <b>{info.count}</b></p>
            <p>Total: <b>R$ {info.total.toFixed(2)}</b></p>
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Enviar WhatsApp (teste)</h3>
        <form className="row" onSubmit={sendWhatsApp}>
          <input placeholder="Para (55DDDNYYYYYYY)" value={send.to} onChange={e=>setSend({...send, to:e.target.value})} />
          <input placeholder="Mensagem" value={send.message} onChange={e=>setSend({...send, message:e.target.value})} />
          <button>Enviar</button>
        </form>
        {status && <p style={{marginTop:8}}>{status}</p>}
        <p style={{opacity:.7}}>Requer configurar o provedor no backend (.env).</p>
      </div>
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}


function Onboarding({ onDone }){
  const [step, setStep] = useState(1)
  const steps = [
    { t:'Bem-vindo!', d:'Vamos configurar rapidamente seu CRM: equipe, clientes e pipeline.' },
    { t:'Adicione sua equipe', d:'Crie usuários no backend (admin) e defina responsáveis dos negócios.' },
    { t:'Importe seus dados', d:'Use Importar CSV para clientes e negócios e comece em minutos.' },
  ]
  const s = steps[step-1]
  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.5)', display:'grid', placeItems:'center', zIndex:50}}>
      <div className="card" style={{maxWidth:520}}>
        <h2 style={{marginTop:0}}>{s.t}</h2>
        <p>{s.d}</p>
        <div className="row">
          {step>1 && <button onClick={()=>setStep(step-1)}>Voltar</button>}
          {step<steps.length && <button onClick={()=>setStep(step+1)}>Avançar</button>}
          {step===steps.length && <button onClick={()=>{ localStorage.setItem('crm_onboarding','done'); onDone(); }}>Começar</button>}
        </div>
      </div>
    </div>
  )
}


function Tour({ onClose, setPage }){
  const steps = [
    { t:'Dashboard', d:'Veja KPIs, gráfico por etapa e panorama rápido.' , go: ()=>setPage('dashboard') },
    { t:'Clientes', d:'Cadastre, filtre, importe/exporte e defina responsáveis.' , go: ()=>setPage('clients') },
    { t:'Negócios', d:'Crie negócios, atribua owner e filtre por responsável.' , go: ()=>setPage('deals') },
    { t:'Kanban', d:'Arraste entre etapas e veja totais R$ por coluna.' , go: ()=>setPage('kanban') },
    { t:'Relatórios', d:'Acompanhe conversão, ticket médio e receita por etapa.' , go: ()=>setPage('reports') },
    { t:'Tarefas', d:'Crie follow-ups e envie lembretes por WhatsApp/E-mail.' , go: ()=>setPage('tasks') },
  ]
  const [i,setI] = React.useState(0)
  const s = steps[i]
  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.55)', display:'grid', placeItems:'center', zIndex:60}}>
      <div className="card" style={{maxWidth:560}}>
        <h2 style={{marginTop:0}}>{s.t}</h2>
        <p>{s.d}</p>
        <div className="row">
          {i>0 && <button onClick={()=>setI(i-1)}>Voltar</button>}
          {i<steps.length-1 && <button onClick={()=>{ s.go(); setI(i+1) }}>Avançar</button>}
          {i===steps.length-1 && <button onClick={onClose}>Concluir</button>}
        </div>
      </div>
    </div>
  )
}

export default function App(){
  const [user, setUser] = useState(null)
  const [page, setPage] = useState('dashboard')
  const [showOB, setShowOB] = useState(false)
  const [showTour, setShowTour] = useState(false)

  useEffect(()=>{
    if(getToken()) setUser({ name: 'Admin' })
  },[])

  if(!user) return <Login onLogin={setUser} />
  return (
    <div className="layout">
      <Sidebar page={page} setPage={setPage} />
      <div style={{flex:1}}>
      <Header user={user} setPage={setPage} onStartTour={()=>setShowTour(true)} />
      {showOB && <Onboarding onDone={()=>setShowOB(false)} />}
      {showTour && <Tour onClose={()=>setShowTour(false)} setPage={setPage} />}
      {page==='dashboard' && <Dashboard />}
      {page==='clients' && <Clients />}
      {page==='deals' && <Deals />}
      {page==='kanban' && <Kanban />}
      {page==='reports' && <Reports />}
      {page==='tasks' && <Tasks />}
      {page==='adminpwa' && <AdminPWA />}
      </div>
      <div className="card">
        <h3>Vendas por etapa</h3>
        <svg width="800" height="220" style={{background:'#0e0e0e', border:'1px solid #2a2a2a', borderRadius:8}}>
          {Object.entries(byStage).map(([k,v],i)=>{
            const max = Math.max(1, ...Object.values(byStage))
            const bw = 120, pad = 24, h = (v/max)*160, x = 30 + i*(bw+pad), y = 180 - h
            return (<g key={k}><rect x={x} y={y} width={bw} height={h} rx="8" /><text x={x+bw/2} y={200} textAnchor="middle" fontSize="12" fill="#fff">{k}</text><text x={x+bw/2} y={y-6} textAnchor="middle" fontSize="12" fill="#fff">R$ {v.toFixed(0)}</text></g>)
          })}
        </svg>
      </div>
    </div>
  )
}
