# CRM Frontend (React + Vite)

## Rodar local
```bash
cd frontend
npm install
# opcional: criar arquivo .env com VITE_API_URL=http://localhost:4000
npm run dev
```
App em `http://localhost:5173`
