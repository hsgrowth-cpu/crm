import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { initDb } from './db.js';
import nodemailer from 'nodemailer';
import webpush from 'web-push';
import { requireAuth } from './authMiddleware.js';

function requireRole(role){
  return (req,res,next)=>{
    if(!req.user || (req.user.role!==role && req.user.role!=='admin')){
      return res.status(403).json({ error:'Forbidden' });
    }
    next();
  }
}


const app = express();

// Web Push config
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || 'mailto:admin@example.com',
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
}

async function sendMail(to, subject, text){
  try{
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE||'false') === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
    });
    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || 'no-reply@example.com',
      to, subject, text
    });
    return { ok:true, messageId: info.messageId };
  }catch(e){ return { ok:false, error: String(e) } }
}

function jsonString(obj){try{return JSON.stringify(obj)}catch{return '{}'}}
app.use(express.json());
app.use(cors({ origin: process.env.ORIGIN?.split(',') || '*'}));

let db;
function isSeller(req){ return req.user && req.user.role==='seller'; }
async function canEditClient(id, req){
  if (!isSeller(req)) return true;
  const row = await db.get('SELECT owner, owner_user_id FROM clients WHERE id=?', [id]);
  if (!row) return false;
  const owner = (row.owner||'').trim().toLowerCase();
  const uname = (req.user.name||'').trim().toLowerCase();
  if (Number(row.owner_user_id||0) === Number(req.user.id||0)) return true;
  return owner && uname && owner === uname;
}
async function canEditDeal(id, req){
  if (!isSeller(req)) return true;
  const row = await db.get('SELECT owner_user_id FROM deals WHERE id=?', [id]);
  if (!row) return false;
  return Number(row.owner_user_id||0) === Number(req.user.id||0);
}

(async () => {
  db = await initDb();
  // deals migration owner_user_id
  try {
    const cols = await db.all(\"PRAGMA table_info(deals)\");
    const names = cols.map(c=>c.name);
    if(!names.includes('owner_user_id')){
      await db.exec(\"ALTER TABLE deals ADD COLUMN owner_user_id INTEGER;\");
    }
  } catch(e) { console.log('migration deals owner_user_id', e.message); }
  // Seed admin if none
  const user = await db.get('SELECT * FROM users LIMIT 1');
  if (!user) {

if (process.env.SEED === 'true') {
  try {
    // Users seed
    const ucount = await db.get('SELECT COUNT(*) as c FROM users'); 
    if (ucount.c < 3){
      const bcrypt = (await import('bcryptjs')).default;
      const mk = async (name,email,role) => {
        const hash = bcrypt.hashSync('123456', 10);
        try { await db.run('INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)', [name,email,hash,role]); } catch {}
      }
      await mk('Gestor', 'gestor@hsgrowth.com', 'manager');
      await mk('Vendedor A', 'seller.a@hsgrowth.com', 'seller');
      await mk('Vendedor B', 'seller.b@hsgrowth.com', 'seller');
    }
    // Clients seed
    const ccount = await db.get('SELECT COUNT(*) as c FROM clients');
    if (ccount.c < 5){
      const users = await db.all('SELECT id,name FROM users');
      const pick = (n) => users.find(u=>u.name.includes(n))?.id || users[0]?.id;
      const seedClients = [
        ['AmazonTec', 'contato@amazontec.com', '92999990001', 'AmazonTec', 'lead', 'Instagram', 'Gestor', 'tech,hot', pick('Gestor')],
        ['Padaria Bom Sabor', 'vendas@bomsabor.com', '92999990002', 'Bom Sabor', 'proposal', 'Indicação', 'Vendedor A', 'food', pick('Vendedor A')],
        ['Colégio Manaus', 'contato@colegiomanaus.com', '92999990003', 'Colégio Manaus', 'lead', 'Evento', 'Vendedor B', 'educação', pick('Vendedor B')],
        ['Tokio Pro Áudio', 'contato@tokioaudio.com', '92999990004', 'Tokio Pro', 'won', 'Google', 'Gestor', 'audio,pro', pick('Gestor')],
        ['Jessy Calçados', 'contato@jessy.com', '92999990005', 'Jessy', 'lost', 'Facebook', 'Vendedor A', 'retail', pick('Vendedor A')],
      ];
      for (const r of seedClients){
        await db.run('INSERT INTO clients (name,email,phone,company,status,source,owner,tags,owner_user_id) VALUES (?,?,?,?,?,?,?,?,?)', r);
      }
    }
    // Deals seed
    const dcount = await db.get('SELECT COUNT(*) as c FROM deals');
    if (dcount.c < 8){
      const clients = await db.all('SELECT id, owner_user_id FROM clients');
      const now = new Date();
      const add = async (ci,val,st,days,owner) => {
        const exp = new Date(now.getTime()+days*86400000).toISOString().slice(0,10);
        await db.run('INSERT INTO deals (client_id,value,stage,expected_close,owner_user_id) VALUES (?,?,?,?,?)',[ci,val,st,exp,owner]);
      }
      for (const c of clients){
        await add(c.id, Math.floor(Math.random()*8000+1000), 'new', 7, c.owner_user_id);
        await add(c.id, Math.floor(Math.random()*9000+2000), 'proposal', 14, c.owner_user_id);
      }
    }
    console.log('Seed concluído.');
  } catch(e){ console.log('Seed falhou', e.message); }
}

     const hash = bcrypt.hashSync('admin123', 10);
     await db.run('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
      ['Admin', 'admin@hsgrowth.com', hash, 'admin']);
     console.log('Seeded admin user: admin@hsgrowth.com / admin123');
  }
})();

// Health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Auth
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role, name: user.name }, process.env.JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// Users (admin only minimal)
// Users list (basic)
app.get('/api/users', requireAuth, async (req, res) => {
  const rows = await db.all('SELECT id, name, email, role FROM users ORDER BY name ASC');
  res.json(rows);
});

app.post('/api/users', requireAuth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const { name, email, password, role='seller' } = req.body;
  const hash = bcrypt.hashSync(password, 10);
  try {
    const result = await db.run('INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)',
      [name, email, hash, role]);
    res.json({ id: result.lastID });
  } catch (e) {
    res.status(400).json({ error: 'Email already exists' });
  }
});

// Clients
app.get('/api/clients', requireAuth, async (req, res) => {
  const rows = await db.all('SELECT * FROM clients ORDER BY id DESC');
  res.json(rows);
});
app.post('/api/clients', requireAuth, async (req, res) => {
  const { name, email, phone, company, status='lead', source=null, owner=null, tags=null, owner_user_id=null } = req.body;
  const result = await db.run('INSERT INTO clients (name, email, phone, company, status, source, owner, tags, owner_user_id) VALUES (?,?,?,?,?,?,?,?,?)',
    [name, email, phone, company, status, source, owner, tags, owner_user_id]);
  res.json({ id: result.lastID });
});
app.put('/api/clients/:id', requireAuth, async (req, res) => {
  const { id } = req.params;
  if (!(await canEditClient(id, req))) return res.status(403).json({ error: 'Not allowed' });
  const { name, email, phone, company, status, source, owner, tags, owner_user_id } = req.body;
  await db.run('UPDATE clients SET name=?, email=?, phone=?, company=?, status=?, source=?, owner=?, tags=?, owner_user_id=? WHERE id=?',
    [name, email, phone, company, status, source, owner, tags, owner_user_id, id]);
  res.json({ ok: true });
});
app.delete('/api/clients/:id', requireAuth, async (req, res) => {
  const { id } = req.params;
  if (!(await canEditClient(id, req))) return res.status(403).json({ error: 'Not allowed' });
  await db.run('DELETE FROM clients WHERE id=?', [id]);
  res.json({ ok: true });
});

// Deals
app.get('/api/deals', requireAuth, async (req, res) => {
  let where = 'WHERE 1=1';
  const params = [];
  if(req.query.owner){ where += ' AND d.owner_user_id = ?'; params.push(req.query.owner); }
  const rows = await db.all(`
    SELECT d.*, c.name as client_name 
    FROM deals d JOIN clients c ON c.id = d.client_id
    ${where}
    ORDER BY d.id DESC
  `, params);
  res.json(rows);
});
app.post('/api/deals', requireAuth, async (req, res) => {
  const { client_id, value, stage='new', expected_close=null, owner_user_id=null } = req.body;
  const result = await db.run('INSERT INTO deals (client_id, value, stage, expected_close, owner_user_id) VALUES (?,?,?,?,?)',
    [client_id, value, stage, expected_close, owner_user_id]);
  res.json({ id: result.lastID });
});
app.put('/api/deals/:id', requireAuth, async (req, res) => {
  const { id } = req.params;
  if (!(await canEditDeal(id, req))) return res.status(403).json({ error: 'Not allowed' });
  const { stage, value, expected_close, owner_user_id } = req.body;
  await db.run('UPDATE deals SET stage=?, value=?, expected_close=?, owner_user_id=? WHERE id=?',
    [stage, value, expected_close, owner_user_id, id]);
  res.json({ ok: true });
});
app.delete('/api/deals/:id', requireAuth, async (req, res) => {
  const { id } = req.params;
  if (!(await canEditDeal(id, req))) return res.status(403).json({ error: 'Not allowed' });
  await db.run('DELETE FROM deals WHERE id=?', [id]);
  res.json({ ok: true });
});

// Interactions
app.get('/api/clients/:id/interactions', requireAuth, async (req, res) => {
  const rows = await db.all('SELECT * FROM interactions WHERE client_id = ? ORDER BY date DESC', [req.params.id]);
  res.json(rows);
});
app.post('/api/clients/:id/interactions', requireAuth, async (req, res) => {
  const { type, notes } = req.body;
  const result = await db.run('INSERT INTO interactions (client_id, user_id, type, notes) VALUES (?,?,?,?)',
    [req.params.id, req.user.id, type, notes]);
  res.json({ id: result.lastID });
});


// WhatsApp integration (Zenvia example)
app.post('/api/whatsapp/send', requireAuth, async (req, res) => {
  try {
    const { to, message } = req.body;
    if (!to || !message) return res.status(400).json({ error: 'to and message are required' });

    if (process.env.WHATSAPP_PROVIDER === 'zenvia') {
  const url = (process.env.WHATSAPP_BASE || 'https://api.zenvia.com/v2') + '/channels/whatsapp/messages';
  const payload = {
    from: process.env.WHATSAPP_FROM,
    to: to,
    contents: [{ type: 'text', text: message }]
  };
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-TOKEN': process.env.WHATSAPP_API_KEY || ''
    },
    body: JSON.stringify(payload)
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) return res.status(r.status).json({ error: 'Provider error', details: data });
  return res.json({ ok: true, provider: 'zenvia', response: data });
} else if (process.env.WHATSAPP_PROVIDER === 'wati') {
  // WATI Cloud API (exemplo)
  const base = process.env.WHATSAPP_BASE || 'https://live-server-XXXXXX.api.wati.io';
  const url = base + '/api/v1/sendSessionMessage';
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (process.env.WHATSAPP_API_KEY || '')
    },
    body: JSON.stringify({ whatsappNumber: to, messageText: message })
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) return res.status(r.status).json({ error: 'Provider error', details: data });
  return res.json({ ok: true, provider: 'wati', response: data });
} else if (process.env.WHATSAPP_PROVIDER === 'gupshup') {
  // Gupshup WhatsApp API (exemplo)
  const url = (process.env.WHATSAPP_BASE || 'https://api.gupshup.io') + '/sm/api/v1/msg';
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'apikey': process.env.WHATSAPP_API_KEY || '',
      'Accept': 'application/json'
    },
    body: new URLSearchParams({
      channel: 'whatsapp',
      source: process.env.WHATSAPP_FROM || '',
      destination: to,
      'message': jsonString({ type: 'text', text: message })
    })
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) return res.status(r.status).json({ error: 'Provider error', details: data });
  return res.json({ ok: true, provider: 'gupshup', response: data });

      const url = (process.env.WHATSAPP_BASE || 'https://api.zenvia.com/v2') + '/channels/whatsapp/messages';
      const payload = {
        from: process.env.WHATSAPP_FROM,
        to: to,
        contents: [{ type: 'text', text: message }]
      };
      const r = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-TOKEN': process.env.WHATSAPP_API_KEY || ''
        },
        body: JSON.stringify(payload)
      });
      const data = await r.json().catch(()=>({}));
      if (!r.ok) {
        return res.status(r.status).json({ error: 'Provider error', details: data });
      }
      return res.json({ ok: true, provider: 'zenvia', response: data });
    }

    return res.status(400).json({ error: 'Unsupported provider. Set WHATSAPP_PROVIDER=zenvia' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Internal error' });
  }
});


// Tasks CRUD
app.get('/api/tasks', requireAuth, async (req,res)=>{
  const { only_open } = req.query;
  const rows = await db.all(`
    SELECT t.*, c.name as client_name, u.name as assigned_name
    FROM tasks t
    LEFT JOIN clients c ON c.id = t.client_id
    LEFT JOIN users u ON u.id = t.assigned_to
    ${only_open ? 'WHERE t.done = 0' : ''}
    ORDER BY COALESCE(t.due_at, '') ASC, t.id DESC
  `);
  res.json(rows);
});
app.post('/api/tasks', requireAuth, async (req,res)=>{
  const { title, due_at, client_id, assigned_to, channel='whatsapp', notes } = req.body;
  const r = await db.run(
    'INSERT INTO tasks (title, due_at, client_id, assigned_to, channel, notes) VALUES (?,?,?,?,?,?)',
    [title, due_at, client_id || null, assigned_to || null, channel, notes || null]
  );
  res.json({ id: r.lastID });
});
app.put('/api/tasks/:id', requireAuth, async (req,res)=>{
  const { id } = req.params;
  const { title, due_at, client_id, assigned_to, channel, notes, done } = req.body;
  await db.run(
    'UPDATE tasks SET title=?, due_at=?, client_id=?, assigned_to=?, channel=?, notes=?, done=? WHERE id=?',
    [title, due_at, client_id || null, assigned_to || null, channel, notes || null, done ? 1 : 0, id]
  );
  res.json({ ok: true });
});
app.delete('/api/tasks/:id', requireRole('manager'), async (req,res)=>{
  const { id } = req.params;
  await db.run('DELETE FROM tasks WHERE id=?',[id]);
  res.json({ ok: true });
});

// Run reminders manually (send WhatsApp if due)
app.post('/api/tasks/run-reminders', requireAuth, async (req,res)=>{
  const now = new Date().toISOString();
  const due = await db.all("SELECT * FROM tasks WHERE done=0 AND due_at IS NOT NULL AND due_at <= ?", [now]);
  const sent = [];
  for (const t of due){
    if (t.channel === 'whatsapp') {
      try {
        const r = await fetch((process.env.ORIGIN || '').replace(/\/$/,'') + '/api/whatsapp/send', {
          method:'POST',
          headers:{ 'Content-Type':'application/json', 'Authorization': req.headers.authorization || '' },
          body: JSON.stringify({ to: process.env.WHATSAPP_TEST_TO || '', message: `[Lembrete] ${t.title}` })
        });
        const js = await r.json().catch(()=>({}));
        sent.push({ id: t.id, ok: r.ok, resp: js });
      } catch(e){
        sent.push({ id: t.id, ok:false, error: String(e) });
      }
    } else {
      // email stub
      const m = await sendMail(process.env.SMTP_TEST_TO || '', `[Lembrete] ${t.title}`, t.notes || '');
    sent.push({ id: t.id, ok:m.ok, resp:m });
    }
  }
  res.json({ now, count: due.length, details: sent });
});


// Push: expose public key
app.get('/api/push/public-key', async (req,res)=>{
  res.json({ publicKey: process.env.VAPID_PUBLIC_KEY || null });
});
// Push: subscribe
app.post('/api/push/subscribe', requireAuth, async (req,res)=>{
  const { endpoint, keys } = req.body || {};
  if (!endpoint || !keys) return res.status(400).json({ error: 'invalid subscription' });
  try{
    await db.run('INSERT OR IGNORE INTO push_subs (endpoint, p256dh, auth) VALUES (?,?,?)', [endpoint, keys.p256dh, keys.auth]);
    res.json({ ok: true });
  }catch(e){ res.status(500).json({ error: String(e) }); }
});
// Push: broadcast test
app.post('/api/push/test-broadcast', requireRole('manager'), async (req,res)=>{
  try{
    const subs = await db.all('SELECT * FROM push_subs');
    const payload = JSON.stringify({ title: 'HS Growth CRM', body: req.body?.message || 'Notificação de teste', url: '/' });
    const results = [];
    for (const s of subs){
      try{
        const r = await webpush.sendNotification({
          endpoint: s.endpoint,
          keys: { p256dh: s.p256dh, auth: s.auth }
        }, payload);
        results.push({ endpoint: s.endpoint, ok: true });
      }catch(e){
        results.push({ endpoint: s.endpoint, ok:false, error: String(e) });
      }
    }
    res.json({ ok: true, sent: results.length, results });
  }catch(e){ res.status(500).json({ error: String(e) }); }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`CRM API running on http://localhost:${PORT}`);
});
