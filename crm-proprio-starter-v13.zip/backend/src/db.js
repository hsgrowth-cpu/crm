import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';
import fs from 'fs';

export async function initDb() {
  const dbFile = process.env.DATABASE_FILE || './data.sqlite';
  const dbDir = path.dirname(dbFile);
  if (!fs.existsSync(dbDir) && dbDir not in ['.', '']) {
    fs.mkdirSync(dbDir, { recursive: true });
  }
  const db = await open({ filename: dbFile, driver: sqlite3.Database });
  // Enable FKs
  await db.exec('PRAGMA foreign_keys = ON;');
  // Create tables if not exist
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'seller',
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      company TEXT,
      status TEXT DEFAULT 'lead',
      source TEXT,      -- origem do lead (ex: Instagram, Indicação)
      owner TEXT,       -- responsável (ex: Hallysson)
      tags TEXT,        -- tags separadas por vírgula
      owner_user_id INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS deals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      value REAL NOT NULL DEFAULT 0,
      stage TEXT NOT NULL DEFAULT 'new',
      expected_close TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS interactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      user_id INTEGER,
      date TEXT DEFAULT (datetime('now')),
      type TEXT,
      notes TEXT,
      FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );
  `);
  return db;
}

// migrations: ensure columns exist in clients
const cols = await db.all("PRAGMA table_info(clients)");
const names = cols.map(c => c.name);
const addCol = async (n, def) => {
  if (!names.includes(n)) {
    await db.exec(`ALTER TABLE clients ADD COLUMN ${n} ${def};`);
  }
};
await addCol('source', 'TEXT');
await addCol('owner', 'TEXT');
await addCol('tags', 'TEXT');
        await addCol('owner_user_id', 'INTEGER');

// Tasks
await db.exec(`
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    due_at TEXT, -- ISO datetime
    client_id INTEGER,
    assigned_to INTEGER, -- user id
    channel TEXT, -- 'whatsapp' | 'email'
    notes TEXT,
    done INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE SET NULL,
    FOREIGN KEY(assigned_to) REFERENCES users(id) ON DELETE SET NULL
  );
`);


// Web Push subscriptions
await db.exec(`
  CREATE TABLE IF NOT EXISTS push_subs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    endpoint TEXT UNIQUE,
    p256dh TEXT,
    auth TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);
